#include<stdio.h>//
#include<conio.h>//
void main()//
{
    
    printf("\n name:Romit");
    printf("\n birth date:18-08-2007");
    printf("\n age:18");
    printf("\n address:param anand golden park-1 near raiya telephone exchange rajkot");
    
    getch();
}
    
