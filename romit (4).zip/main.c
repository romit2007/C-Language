#include<stdio.h>//
#include<conio.h>//
void main()//
{
    
    printf("name \t age");
    printf("\n romit \t 18");
    printf("\n dhyani\t 18");
    printf("\n jeel \t 18");
    printf("\n siya \t 18");
    
    
    
    getch();
}
    
    
