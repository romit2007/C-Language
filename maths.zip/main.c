#include<stdio.h>
#include<conio.h>
void main()
{
    int num1 = 6;
    int num2 = 4;
    int add,division,sub,mul;
    
    add = num1+num2;
    printf("\n Addition is %d and %d  is %d",num1,num2,add);
    
    sub = num1-num2;
    printf("\n Substrection is %d and %d  is %d",num1,num2,sub);
    
    mul = num1*num2;
    printf("\n Multiplication is %d and %d  is %d",num1,num2,mul);
    
    division = num1/num2;
    printf("\n Division is %d and %d  is %d",num1,num2,division);
    
    getch();
}
    
    
    



